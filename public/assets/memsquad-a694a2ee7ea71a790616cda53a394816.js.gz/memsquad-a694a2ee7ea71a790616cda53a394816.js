// Closes the Responsive Menu on Menu Item Click
$(document).ready(function() {
    $('#t').click(function() {
        $('.navbar-toggle:visible').click();
    });
    
    $('#p').click(function() {
        $('.navbar-toggle:visible').click();
    });
});
